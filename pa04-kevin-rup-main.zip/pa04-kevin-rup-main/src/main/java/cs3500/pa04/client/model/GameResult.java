package cs3500.pa04.client.model;

/**
 * represents possible values for a game result
 */
public enum GameResult {
  WIN,
  LOSE,
  DRAW
}
